package edu.gascnagercoil.environmentalsciences.data

import android.content.Context
import edu.gascnagercoil.environmentalsciences.R
import edu.gascnagercoil.environmentalsciences.model.*
import org.json.JSONArray
import org.json.JSONObject

class ContentRepository(private val context: Context) {
    fun load(): Book {
        val json = context.resources.openRawResource(R.raw.book_content).bufferedReader(Charsets.UTF_8).use { it.readText() }
        val root = JSONObject(json)
        return Book(
            titleEn = root.getString("titleEn"),
            titleTa = root.getString("titleTa"),
            subtitleEn = root.getString("subtitleEn"),
            subtitleTa = root.getString("subtitleTa"),
            units = root.getJSONArray("units").toObjects(::parseUnit),
            supplemental = root.getJSONArray("supplemental").toObjects(::parseSupplemental),
            privacy = parsePrivacy(root.getJSONObject("privacy"))
        )
    }

    private fun parseUnit(o: JSONObject) = UnitContent(
        number = o.getInt("number"),
        titleEn = o.optString("titleEn"),
        titleTa = o.optString("titleTa"),
        opening = o.getJSONArray("opening").toObjects(::parseBlock),
        lessons = o.getJSONArray("lessons").toObjects(::parseLesson),
        review = o.getJSONArray("review").toObjects(::parseBlock),
        quiz = o.getJSONArray("quiz").toObjects(::parseQuiz)
    )

    private fun parseLesson(o: JSONObject) = Lesson(
        id = o.optString("id"),
        number = o.optString("number"),
        titleEn = o.optString("titleEn"),
        titleTa = o.optString("titleTa"),
        english = o.getJSONArray("english").toObjects(::parseBlock),
        tamil = o.getJSONArray("tamil").toObjects(::parseBlock)
    )

    private fun parseBlock(o: JSONObject) = ContentBlock(
        kind = o.optString("kind", "text"),
        title = o.optString("title"),
        text = o.optString("text"),
        items = o.optJSONArray("items")?.toStrings().orEmpty(),
        rows = o.optJSONArray("rows")?.toRows().orEmpty(),
        figure = if (o.has("figure")) o.optString("figure").takeIf { it.isNotBlank() } else null,
        caption = o.optString("caption")
    )

    private fun parseQuiz(o: JSONObject) = QuizQuestion(
        questionEn = o.optString("questionEn"),
        questionTa = o.optString("questionTa"),
        options = o.getJSONArray("options").toObjects {
            BilingualText(it.optString("en"), it.optString("ta"))
        },
        answer = o.getInt("answer")
    )

    private fun parseSupplemental(o: JSONObject) = SupplementalSection(
        key = o.optString("key"),
        title = o.optString("title"),
        blocks = o.getJSONArray("blocks").toObjects(::parseBlock)
    )

    private fun parsePrivacy(o: JSONObject) = PrivacyPolicy(
        version = o.optString("version"),
        english = o.getJSONArray("english").toStrings(),
        tamil = o.getJSONArray("tamil").toStrings(),
        credit = o.getJSONArray("credit").toStrings()
    )
}

private fun <T> JSONArray.toObjects(parser: (JSONObject) -> T): List<T> =
    (0 until length()).map { parser(getJSONObject(it)) }

private fun JSONArray.toStrings(): List<String> =
    (0 until length()).map { getString(it) }

private fun JSONArray.toRows(): List<List<String>> =
    (0 until length()).map { getJSONArray(it).toStrings() }
