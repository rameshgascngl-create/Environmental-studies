package edu.gascnagercoil.environmentalsciences.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlin.math.pow

/**
 * A genuinely animated, native replacement for the static carbon-cycle figure
 * (fig_010_u02_en.png / fig_064_u02_ta.png). Draws the same four-reservoir ring
 * used in those images, but a moving indicator continuously travels the loop,
 * so the *direction and continuity of flow* — the actual concept a biogeochemical
 * cycle is teaching — is shown, not just implied by a static arrowhead.
 *
 * The static PNGs are kept and still used for the pinch-zoom detail view
 * (ZoomDialog in NativeContent.kt); this composable is only the inline,
 * in-lesson teaching view.
 */

private data class CycleNode(val label: String, val fx: Float, val fy: Float)

private fun cubicPoint(p0: Offset, p1: Offset, p2: Offset, p3: Offset, t: Float): Offset {
    val u = 1f - t
    val x = u.pow(3) * p0.x + 3 * u.pow(2) * t * p1.x + 3 * u * t.pow(2) * p2.x + t.pow(3) * p3.x
    val y = u.pow(3) * p0.y + 3 * u.pow(2) * t * p1.y + 3 * u * t.pow(2) * p2.y + t.pow(3) * p3.y
    return Offset(x, y)
}

@Composable
fun AnimatedCarbonCycle(isTamil: Boolean) {
    val nodes = if (isTamil) listOf(
        CycleNode("காற்று", 0.5f, 0.10f),
        CycleNode("தாவரங்கள்", 0.84f, 0.42f),
        CycleNode("விலங்குகள்", 0.63f, 0.85f),
        CycleNode("மண் / நுண்ணுயிரிகள்", 0.16f, 0.42f)
    ) else listOf(
        CycleNode("Atmosphere", 0.5f, 0.10f),
        CycleNode("Plants", 0.84f, 0.42f),
        CycleNode("Animals", 0.63f, 0.85f),
        CycleNode("Soil & decomposers", 0.16f, 0.42f)
    )
    val edgeLabels = if (isTamil)
        listOf("ஒளிச்சேர்க்கை", "உண்ணுதல்", "இறப்பு / கழிவு", "சிதைவு")
    else
        listOf("photosynthesis", "consumption", "death / waste", "decomposition")

    val caption = if (isTamil)
        "கார்பன் சுழற்சி: இயக்கும் புள்ளி மூடிய சுழற்சி வழியாக ஓட்டத்தைக் காட்டுகிறது."
    else
        "Carbon cycle: the moving point traces the flow through a closed loop, not a one-way chain."

    val transition = rememberInfiniteTransition(label = "carbonCycle")
    val progress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 4f, // 4 ring segments; integer part = segment index, fraction = position within it
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "carbonCycleProgress"
    )

    val ring = MaterialTheme.colorScheme.primary
    val respirationColor = Color(0xFFA8763F)

    Column(Modifier.fillMaxWidth()) {
        BoxWithConstraints(Modifier.fillMaxWidth().height(300.dp)) {
            val wPx = with(androidx.compose.ui.platform.LocalDensity.current) { maxWidth.toPx() }
            val hPx = with(androidx.compose.ui.platform.LocalDensity.current) { maxHeight.toPx() }
            fun at(n: CycleNode) = Offset(n.fx * wPx, n.fy * hPx)
            val p0 = at(nodes[0]); val p1 = at(nodes[1]); val p2 = at(nodes[2]); val p3 = at(nodes[3])
            // control points bow each arc outward, matching the original diagram's curvature
            val c01a = Offset((p0.x + p1.x) / 2f + 60f, p0.y + 40f)
            val c01b = Offset((p0.x + p1.x) / 2f + 10f, p1.y - 60f)
            val c12a = Offset(p1.x - 10f, (p1.y + p2.y) / 2f + 30f)
            val c12b = Offset(p2.x + 60f, (p1.y + p2.y) / 2f - 10f)
            val c23a = Offset((p2.x + p3.x) / 2f + 10f, p2.y + 10f)
            val c23b = Offset((p2.x + p3.x) / 2f - 60f, p3.y + 40f)
            val c30a = Offset(p3.x + 60f, (p3.y + p0.y) / 2f + 10f)
            val c30b = Offset(p0.x - 60f, (p3.y + p0.y) / 2f - 10f)

            Canvas(Modifier.fillMaxWidth().height(300.dp)) {
                val path = Path().apply {
                    moveTo(p0.x, p0.y); cubicTo(c01a.x, c01a.y, c01b.x, c01b.y, p1.x, p1.y)
                    cubicTo(c12a.x, c12a.y, c12b.x, c12b.y, p2.x, p2.y)
                    cubicTo(c23a.x, c23a.y, c23b.x, c23b.y, p3.x, p3.y)
                    cubicTo(c30a.x, c30a.y, c30b.x, c30b.y, p0.x, p0.y)
                }
                drawPath(path, ring, style = Stroke(width = 5f))

                // direct respiration shortcuts (Plants -> Atmosphere, Animals -> Atmosphere), dashed
                val dash = PathEffect.dashPathEffect(floatArrayOf(10f, 12f), 0f)
                drawLine(respirationColor, p1, p0, strokeWidth = 4f, pathEffect = dash)
                drawLine(respirationColor, p2, p0, strokeWidth = 4f, pathEffect = dash)

                // the animated flow indicator
                val seg = progress.toInt().coerceIn(0, 3)
                val t = progress - seg
                val dot = when (seg) {
                    0 -> cubicPoint(p0, c01a, c01b, p1, t)
                    1 -> cubicPoint(p1, c12a, c12b, p2, t)
                    2 -> cubicPoint(p2, c23a, c23b, p3, t)
                    else -> cubicPoint(p3, c30a, c30b, p0, t)
                }
                drawCircle(ring, radius = 10f, center = dot)
                drawCircle(ring.copy(alpha = 0.35f), radius = 18f, center = dot)
            }

            nodes.forEachIndexed { i, n ->
                Surface(
                    modifier = Modifier
                        .offset(
                            x = with(androidx.compose.ui.platform.LocalDensity.current) { (n.fx * wPx - 70f).toDp() },
                            y = with(androidx.compose.ui.platform.LocalDensity.current) { (n.fy * hPx - 20f).toDp() }
                        )
                        .width(140.dp),
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Text(
                        n.label,
                        modifier = Modifier.padding(6.dp).fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
        edgeLabels.forEach { label ->
            Text("• $label", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(start = 4.dp))
        }
        Text(caption, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
    }
}
