package edu.gascnagercoil.environmentalsciences

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import edu.gascnagercoil.environmentalsciences.ui.EnvironmentalStudiesApp
import edu.gascnagercoil.environmentalsciences.ui.theme.EnvironmentalStudiesTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EnvironmentalStudiesTheme {
                EnvironmentalStudiesApp()
            }
        }
    }
}
