package edu.gascnagercoil.environmentalsciences.model

data class Book(
    val titleEn: String,
    val titleTa: String,
    val subtitleEn: String,
    val subtitleTa: String,
    val units: List<UnitContent>,
    val supplemental: List<SupplementalSection>,
    val privacy: PrivacyPolicy
)

data class UnitContent(
    val number: Int,
    val titleEn: String,
    val titleTa: String,
    val opening: List<ContentBlock>,
    val lessons: List<Lesson>,
    val review: List<ContentBlock>,
    val quiz: List<QuizQuestion>
)

data class Lesson(
    val id: String,
    val number: String,
    val titleEn: String,
    val titleTa: String,
    val english: List<ContentBlock>,
    val tamil: List<ContentBlock>
)

data class ContentBlock(
    val kind: String,
    val title: String,
    val text: String,
    val items: List<String>,
    val rows: List<List<String>>,
    val figure: String?,
    val caption: String
)

data class QuizQuestion(
    val questionEn: String,
    val questionTa: String,
    val options: List<BilingualText>,
    val answer: Int
)

data class BilingualText(val en: String, val ta: String)

data class SupplementalSection(
    val key: String,
    val title: String,
    val blocks: List<ContentBlock>
)

data class PrivacyPolicy(
    val version: String,
    val english: List<String>,
    val tamil: List<String>,
    val credit: List<String>
)

enum class LanguageMode { BOTH, ENGLISH, TAMIL }
