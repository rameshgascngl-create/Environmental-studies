package edu.gascnagercoil.environmentalsciences.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow

@Composable
fun SimulationScreen() {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Interactive learning tools", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("ஊடாடும் கற்றல் கருவிகள்", style = MaterialTheme.typography.titleMedium)
            Text(
                "These simplified tools support concept learning; they are educational models, not professional prediction tools.",
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                "இங்கு உள்ள எளிமைப்படுத்தப்பட்ட மாதிரிகள் தேர்ந்தெடுக்கப்பட்ட கருத்துகளைப் புரிந்துகொள்ள உதவுவதற்காக மட்டுமே. அவை தொழில்முறை முன்னறிவிப்பு கருவிகள் அல்ல.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
        item { GreenhouseCard() }
        item { LogisticCard() }
        item { EnergyPyramidCard() }
        item { NoiseCard() }
        item { WastewaterCard() }
    }
}

@Composable
private fun GreenhouseCard() {
    var co2 by rememberSaveableFloat(420f)
    val forcing = 5.35 * ln(co2 / 280.0)
    ToolCard("Greenhouse forcing explorer") {
        Text("CO₂: ${co2.toInt()} ppm")
        Slider(value = co2, onValueChange = { co2 = it }, valueRange = 280f..1000f)
        Text("ΔF = ${"%.2f".format(forcing)} W m⁻²", style = MaterialTheme.typography.titleLarge)
        Text("Uses ΔF = 5.35 ln(C/280). Educational radiative-forcing approximation, not a temperature prediction.")
    }
}

@Composable
private fun LogisticCard() {
    var ratePercent by rememberSaveableFloat(35f)
    var capacity by rememberSaveableFloat(800f)
    val r = ratePercent / 100f
    val primary = MaterialTheme.colorScheme.primary
    ToolCard("Logistic population growth") {
        Text("r: ${"%.2f".format(r)}")
        Slider(value = ratePercent, onValueChange = { ratePercent = it }, valueRange = 5f..100f)
        Text("K: ${capacity.toInt()}")
        Slider(value = capacity, onValueChange = { capacity = it }, valueRange = 200f..1400f)
        Canvas(Modifier.fillMaxWidth().height(220.dp)) {
            val w = size.width
            val h = size.height
            val grid = androidx.compose.ui.graphics.Color.Gray.copy(alpha = .22f)
            for (i in 1..4) drawLine(grid, Offset(0f, h * i / 5f), Offset(w, h * i / 5f), 1f)
            val path = Path()
            var n = 10f
            for (t in 0..120) {
                n += r * n * (1f - n / capacity) * .18f
                val x = t / 120f * w
                val y = h - 10f - (n / capacity) * (h - 25f)
                if (t == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, primary, style = Stroke(width = 5f, cap = StrokeCap.Round))
        }
        Text("A native reproduction of the original logistic-growth teaching model.")
    }
}

@Composable
private fun EnergyPyramidCard() {
    var producer by rememberSaveableFloat(10000f)
    var efficiency by rememberSaveableFloat(10f)
    val ef = efficiency / 100f
    val values = listOf(producer, producer * ef, producer * ef * ef, producer * ef * ef * ef)
    val names = listOf("Producers", "Primary consumers", "Secondary consumers", "Tertiary consumers")
    ToolCard("Energy pyramid") {
        Text("Producer energy: ${producer.toInt()}")
        Slider(value = producer, onValueChange = { producer = (it / 500f).toInt() * 500f }, valueRange = 1000f..20000f)
        Text("Transfer efficiency: ${efficiency.toInt()}%")
        Slider(value = efficiency, onValueChange = { efficiency = it }, valueRange = 5f..20f)
        values.forEachIndexed { i, value ->
            Box(Modifier.fillMaxWidth().padding(horizontal = (i * 22).dp).background(MaterialTheme.colorScheme.secondaryContainer).padding(8.dp)) {
                Text("${names[i]} · ${"%.1f".format(value)}")
            }
        }
        Text("The 10% value is a heuristic; real transfer efficiencies vary.")
    }
}

@Composable
private fun NoiseCard() {
    var a by rememberSaveableFloat(70f)
    var b by rememberSaveableFloat(70f)
    val total = 10 * log10(10.0.pow(a / 10.0) + 10.0.pow(b / 10.0))
    ToolCard("Noise addition") {
        Text("A: ${a.toInt()} dB")
        Slider(value = a, onValueChange = { a = it }, valueRange = 30f..100f)
        Text("B: ${b.toInt()} dB")
        Slider(value = b, onValueChange = { b = it }, valueRange = 30f..100f)
        Text("Combined: ${"%.1f".format(total)} dB", style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
private fun WastewaterCard() {
    val stages = listOf("Screening", "Primary settling", "Biological", "Secondary settling", "Polishing")
    val desc = listOf(
        "Screening removes coarse solids.",
        "Primary settling removes settleable solids.",
        "Biological treatment oxidises dissolved and fine organic matter.",
        "Secondary settling separates biomass from treated water.",
        "Disinfection or polishing targets remaining pathogens or contaminants."
    )
    var stage by remember { mutableIntStateOf(0) }
    ToolCard("Wastewater train") {
        stages.forEachIndexed { index, name ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = stage == index, onClick = { stage = index })
                Text(name, fontWeight = if (stage == index) FontWeight.Bold else FontWeight.Normal)
            }
        }
        Text(desc[stage])
        Button(onClick = { stage = (stage + 1) % stages.size }) { Text("Advance") }
    }
}

@Composable
private fun ToolCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
private fun rememberSaveableFloat(initial: Float): MutableState<Float> {
    return androidx.compose.runtime.saveable.rememberSaveable { mutableFloatStateOf(initial) }
}
