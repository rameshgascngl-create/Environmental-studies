# Environmental Studies v1.3.6 → native v2.0.0 content parity

Reference APK SHA-256: `492ae85457c315c6d58241f88abd9475b111f99d948488d15b237f86e86a375b`

## Structural parity

| Item | Reference | Native v2 | Result |
|---|---:|---:|---|
| Units | 9 | 9 | PASS |
| Lessons | 46 | 46 | PASS |
| English lesson sections | 46 | 46 | PASS |
| Tamil lesson sections | 46 | 46 | PASS |
| MCQs | 58 | 58 | PASS |
| Teaching figures | 63 SVG | 63 local PNG | PASS |
| Interactive teaching models | 5 | 5 native Compose models | PASS |

## Text parity method and result

For every English and Tamil lesson section, visible source text was normalized for whitespace. Text internal to SVGs was excluded from the textual comparison because those labels are preserved visually in the corresponding rasterized native figure. Browser controls (`button`, `input`) and script/style text were also excluded. Native structured text included block titles, text, list items, table cells and captions.

**Result: all 92 lesson-language sections achieved 100% source token-multiset coverage.**

The same token-coverage check returned **100%** for:

- Unit opening content, Units 1–9
- Unit review content, Units 1–9
- About this book
- Field and campus learning
- Essential glossary
- Legal/current-information guidance
- References and authoritative further reading

Native output may contain deliberate structural duplication (for example a heading can exist both as a block title and within flattened source text), so native token count can exceed source token count. The gate is designed to detect source omissions, not to claim byte identity between HTML and structured JSON.

## Assessment parity

All 58 source MCQs were compared with the native JSON representation. The comparison covered:

- English question text
- Tamil question text
- English option text
- Tamil option text
- option count/order
- zero-based correct-answer index

**Result: 58/58 exact matches.**

## Figure parity

Every source inline SVG has a provenance record in `MIGRATION_MANIFEST.json` containing its source SHA-256 and generated PNG SHA-256. SVG case-sensitive gradient/filter element names normalized by the HTML parser were restored before rasterization. Tamil figures use a Unicode-capable raster font fallback, and bold weight was downgraded only where the available bold face lacked Tamil glyph coverage.

All 63 generated PNGs passed a basic raster-integrity check (valid dimensions, non-trivial pixel range, and no suspiciously small file). Representative English and Tamil figures, including a gradient-heavy Tamil plate, were visually inspected after the correction.

## Functional migration boundary

The original web reader is **not embedded or emulated**. Its user-facing functions are rebuilt natively: local search, bilingual display, large-text mode, focus mode, figure-only focus, reading progress, reading-position persistence, figure enlargement/zoom, previous/next lesson navigation, native print/PDF, review content, MCQs and five teaching simulations.

This is a source/content parity pass. Physical-device layout, accessibility, print/PDF output, performance and store-review behavior remain part of `DEVICE_QA.md` and are not marked PASS until exercised on the signed production build.
