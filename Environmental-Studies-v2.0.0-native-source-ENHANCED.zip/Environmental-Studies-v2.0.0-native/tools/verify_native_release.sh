#!/usr/bin/env bash
set -euo pipefail
APK="${1:?Usage: verify_native_release.sh path/to/release.apk}"
EXPECTED_PACKAGE="edu.gascnagercoil.environmentalsciences"
EXPECTED_VERSION_NAME="2.0.0"
EXPECTED_VERSION_CODE="20000"
EXPECTED_CERT_SHA256="D82FA964C52E4933A9483A2E2D1BACE7E593A025D17E1213CD3F44D7FE9BA20C"

echo "APK: $APK"
sha256sum "$APK"

if unzip -Z1 "$APK" | grep -Eqi '\.(html?|css|js)$'; then
  echo "FAIL: HTML/CSS/JS runtime asset found in APK" >&2; exit 1
fi
while IFS= read -r dex; do
  if unzip -p "$APK" "$dex" 2>/dev/null | strings | grep -Fq 'android/webkit/WebView'; then
    echo "FAIL: WebView class reference found in $dex" >&2; exit 1
  fi
done < <(unzip -Z1 "$APK" | grep -E '^classes([0-9]+)?\.dex$')

SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
AAPT="$SDK_ROOT/build-tools/35.0.0/aapt"
APKSIGNER="$SDK_ROOT/build-tools/35.0.0/apksigner"
if [[ -x "$AAPT" ]]; then
  BADGING="$($AAPT dump badging "$APK")"
  echo "$BADGING" | head -3
  echo "$BADGING" | grep -q "package: name='$EXPECTED_PACKAGE'"
  echo "$BADGING" | grep -q "versionCode='$EXPECTED_VERSION_CODE'"
  echo "$BADGING" | grep -q "versionName='$EXPECTED_VERSION_NAME'"
  if "$AAPT" dump permissions "$APK" | grep -q 'android.permission.INTERNET'; then
    echo "FAIL: INTERNET permission present" >&2; exit 1
  fi
fi
if [[ -x "$APKSIGNER" ]]; then
  CERT_OUT="$($APKSIGNER verify --verbose --print-certs "$APK")"
  echo "$CERT_OUT"
  ACTUAL_CERT_SHA256="$(echo "$CERT_OUT" | sed -n 's/.*certificate SHA-256 digest: *//Ip' | head -1 | tr -d ':[:space:]' | tr '[:lower:]' '[:upper:]')"
  if [[ -z "$ACTUAL_CERT_SHA256" || "$ACTUAL_CERT_SHA256" != "$EXPECTED_CERT_SHA256" ]]; then
    echo "FAIL: signing certificate does not match v1.3.6 reference" >&2; exit 1
  fi
fi

echo "PASS: native runtime + identity checks"
