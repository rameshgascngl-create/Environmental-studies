from pathlib import Path
import json,re,sys
root=Path(__file__).resolve().parents[1]
app=root/'app'
manifest=json.loads((root/'MIGRATION_MANIFEST.json').read_text())
errors=[]
expected={'units':9,'lessons':46,'mcqs':58,'figures':64,'simulations':5}  # figures: 63 original + fig_064_u02_ta.png
for k,v in expected.items():
    if manifest.get(k)!=v: errors.append(f'{k}: expected {v}, got {manifest.get(k)}')
for p in app.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.html','.htm','.css','.js'}:
        errors.append(f'forbidden runtime asset: {p.relative_to(root)}')
source='\n'.join(p.read_text(errors='ignore') for p in (app/'src'/'main'/'java').rglob('*.kt'))
if 'WebView' in source or 'android.webkit' in source:
    errors.append('WebView/android.webkit reference in Kotlin source')
android_manifest=(app/'src'/'main'/'AndroidManifest.xml').read_text()
if 'android.permission.INTERNET' in android_manifest:
    errors.append('INTERNET permission declared')
gradle=(app/'build.gradle.kts').read_text()
for s in ['applicationId = "edu.gascnagercoil.environmentalsciences"','versionCode = 20000','versionName = "2.0.0"','minSdk = 24','targetSdk = 36']:
    if s not in gradle: errors.append(f'missing build invariant: {s}')
figs=list((app/'src'/'main'/'res'/'drawable-nodpi').glob('fig_*.png'))
if len(figs)!=64: errors.append(f'figure file count {len(figs)} != 64')  # 63 original + fig_064_u02_ta.png (Tamil carbon-cycle figure added to close a real EN/TA gap; see MIGRATION_MANIFEST.postMigrationChanges)
if any(p.stat().st_size < 1000 for p in figs): errors.append('one or more figure PNGs suspiciously small')
book=json.loads((app/'src'/'main'/'res'/'raw'/'book_content.json').read_text())
if len(book['units'])!=9: errors.append('book JSON units != 9')
if sum(len(u['lessons']) for u in book['units'])!=46: errors.append('book JSON lessons != 46')
if sum(len(u['quiz']) for u in book['units'])!=58: errors.append('book JSON MCQs != 58')
if len(book['simulations'])!=5: errors.append('book JSON simulations != 5')
print('REFERENCE_APK_SHA256',manifest['referenceApkSha256'])
print('CONTENT_JSON_SHA256',manifest['generatedContentSha256'])
print('COUNTS',expected)
print('FIGURE_BYTES',sum(p.stat().st_size for p in figs))
if errors:
    print('SOURCE GATE: FAIL')
    for e in errors: print(' -',e)
    sys.exit(1)
print('SOURCE GATE: PASS')
